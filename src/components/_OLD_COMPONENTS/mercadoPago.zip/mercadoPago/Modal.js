import React from 'react';

import './Modal.css';

const modal = (props) => {
    return (
        <div> 
            <div className="modal-body"
             style={{
                  overflow:"auto"
                }}>
                    <p>
                        {props.children}
                    </p>
            </div>
        </div>
    )
}

export default modal;
