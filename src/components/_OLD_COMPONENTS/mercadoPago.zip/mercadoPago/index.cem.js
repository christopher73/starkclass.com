import React, { Component } from "react";
import { connect } from "react-redux";

const baseMercadoPagoUrl =
  "https://secure.mlstatic.com/sdk/javascript/v1/mercadopago.js";
const mercadoPagoId = "mercado-pagojs";
const mercadoPagoUrl = `${baseMercadoPagoUrl}`;

class MercadoPago extends Component {
  constructor(props) {
    super(props);
    this.state = {
      amount: 0,
      cardNumber: "",
      docNumber: "",
      email: ""
    };
  }
  doSubmit = false;

  componentDidMount() {
    if (this.props.cupon === "STARKCLASS50") {
      //check this logic !!!
      alert("cupón aceptado");
      window.location.replace("https://express.culqi.com/pago/6339-2032");
      //window.location.reload();
    } else {
      alert("no valido ");
      window.location.reload();
    }
    const script = document.createElement("script");
    console.log("auth: ", this.props.auth);
    script.id = mercadoPagoId;
    script.src = mercadoPagoUrl;
    script.async = true;
    script.onload = this.mercadoLoad;

    this.mercadoPagoScript = script;

    document.body.appendChild(this.mercadoPagoScript);
    const input = (window.onload = document.getElementById("cardNumber"));
    input.onpaste = function(e) {
      e.preventDefault();
    };
    window.addEventListener("message", this.mercadoEvent, false);
    this.addEvent(document.querySelector("#pay"), "submit", this.doPay);
  }

  initMercadoPago = () => {
    window.Mercadopago.setPublishableKey(
      "APP_USR-7aa96788-ec38-46fb-9f9b-0a01a2104d501"
    );
  };

  mercadoLoad = e => {
    if (window.Mercadopago) {
      this.initMercadoPago();
      console.log("mercadoPago", window.Mercadopago);
    }
  };

  mercadoEvent = mercadoEvent => {
    const { origin, data } = mercadoEvent;
    this.initMercadoPago();

    if (typeof data === "string") {
      console.log("data es igual a string");
      console.log("mercadoPago", window.Mercadopago);
    }
  };

  doPay = event => {
    let cardNumber = this.state.cardNumber;
    event.preventDefault();
    console.log("dopay is called");
    console.log("mercadoPago", window.Mercadopago);

    var $form = document.querySelector("#pay");

    let token = window.Mercadopago.createToken($form, this.sdkResponseHandler); // The function "sdkResponseHandler" is defined below

    console.log("token: ", token);
    return false;
  };

  addEvent(to, type, fn) {
    if (document.addEventListener) {
      to.addEventListener(type, fn, false);
    } else if (document.attachEvent) {
      to.attachEvent("on" + type, fn);
    } else {
      to["on" + type] = fn;
    }
  }

  setPaymentMethodInfo = (status, response) => {
    console.log("status", status);
    console.log("response", response);
    let bin = this.state.cardNumber.substring(0, 6);
    if (status == 200) {
      const paymentMethodElement = document.querySelector(
        "input[name=paymentMethodId]"
      );

      if (paymentMethodElement) {
        paymentMethodElement.value = response[0].id;
      } else {
        let form = document.querySelector("#pay");
        const input = document.createElement("input");
        input.setAttribute("name", "paymentMethodId");
        input.setAttribute("type", "hidden");
        input.setAttribute("value", response[0].id);

        form.appendChild(input);
      }

      window.Mercadopago.getInstallments(
        {
          bin: bin,
          amount: parseFloat(document.querySelector("#amount").value)
        },
        this.setInstallmentInfo
      );
    } else {
      alert(`payment method info error: ${response}`);
    }
  };

  setInstallmentInfo(status, response) {
    var selectorInstallments = document.querySelector("#installments"),
      fragment = document.createDocumentFragment();
    selectorInstallments.options.length = 0;

    if (response.length > 0) {
      var option = new Option("Eliga", "-1"),
        payerCosts = response[0].payer_costs;
      fragment.appendChild(option);

      for (var i = 0; i < payerCosts.length; i++) {
        fragment.appendChild(
          new Option(
            payerCosts[i].recommended_message,
            payerCosts[i].installments
          )
        );
      }

      selectorInstallments.appendChild(fragment);
      selectorInstallments.removeAttribute("disabled");
    }
  }

  guessingPaymentMethod() {
    console.log(this.state);
    var bin = this.state.cardNumber;

    if (bin.length == 6) {
      window.Mercadopago.getPaymentMethod(
        {
          bin: bin
        },
        this.setPaymentMethodInfo
      );
    }
  }

  sdkResponseHandler = (status, response) => {
    console.log("status ", status);
    console.log("response ", response);
    if (status != 200 && status != 201) {
      alert("Error al validar la información");
    } else {
      var form = document.querySelector("#pay");
      var card = document.createElement("input");
      card.setAttribute("name", "token");
      card.setAttribute("type", "hidden");
      card.setAttribute("value", response.id);
      form.appendChild(card);
      this.doSubmit = true;
      form.submit();
    }
  };

  render() {
    return (
      <div></div>
      // <ReactShadowScroll>
      // <form
      //   id="pay"
      //   name="pay"
      //   method="POST"
      //   action={`${process.env.REACT_APP_API_URL}/api/pagos/pay`}
      //   style={{ height: 400, overflow: "auto", overflowX: "hidden" }}
      // >
      //   <div className="row">
      //     <div className="form-group col-lg-6 col-md-6 col-sm-6">
      //       <label htmlFor="cardholderName">Titular de la tarjeta</label>
      //       <input
      //         className="form-control"
      //         type="text"
      //         id="cardholderName"
      //         data-checkout="cardholderName"
      //       />
      //     </div>
      //     <div className="form-group col-lg-6 col-md-6 col-sm-6">
      //       <label htmlFor="email">Email</label>
      //       <input
      //         className="form-control "
      //         type="email"
      //         id="email"
      //         name="email"
      //         value={this.state.email}
      //         onChange={e => {
      //           this.setState({ email: e.target.value });
      //         }}
      //       />
      //     </div>
      //     <div className="form-group col-lg-6 col-md-6 col-sm-12">
      //       <label htmlFor="cardNumber">Número de tarjeta</label>
      //       <input
      //         className="form-control"
      //         type="text"
      //         id="cardNumber"
      //         data-checkout="cardNumber"
      //         value={this.state.cardNumber}
      //         onChange={e => {
      //           this.guessingPaymentMethod();
      //           this.setState({ cardNumber: e.target.value });
      //         }}
      //         onPaste={() => false}
      //         onCopy={() => false}
      //         onCut={() => false}
      //         onDrag={() => false}
      //         onDrop={() => false}
      //         autoComplete="off"
      //       />
      //     </div>
      //     <div className="form-group col-lg-6 col-md-6 col-sm-12">
      //       <label htmlFor="cardExpirationMonth">Mes de expiración</label>
      //       <input
      //         className="form-control"
      //         type="text"
      //         id="cardExpirationMonth"
      //         data-checkout="cardExpirationMonth"
      //         onPaste={() => false}
      //         onCopy={() => false}
      //         onCut={() => false}
      //         onDrag={() => false}
      //         onDrop={() => false}
      //         autoComplete="off"
      //       />
      //     </div>
      //     <div className="form-group col-lg-6 col-md-6 col-sm-12">
      //       <label htmlFor="cardExpirationYear">Año de expiración</label>
      //       <input
      //         className="form-control"
      //         type="text"
      //         id="cardExpirationYear"
      //         data-checkout="cardExpirationYear"
      //         onPaste={() => false}
      //         onCopy={() => false}
      //         onCut={() => false}
      //         onDrag={() => false}
      //         onDrop={() => false}
      //         autoComplete="off"
      //       />
      //     </div>
      //     <div className="form-group col-lg-6 col-md-6 col-sm-12">
      //       <label htmlFor="securityCode">CVV</label>
      //       <input
      //         className="form-control"
      //         type="text"
      //         id="securityCode"
      //         data-checkout="securityCode"
      //         onPaste={() => false}
      //         onCopy={() => false}
      //         onCut={() => false}
      //         onDrag={() => false}
      //         onDrop={() => false}
      //         autoComplete="off"
      //       />
      //     </div>
      //     <div className="form-group col-lg-6 col-md-6 col-sm-12">
      //       <label for="docType">Tipo de documento</label>
      //       <select
      //         id="docType"
      //         data-checkout="docType"
      //         className="form-control"
      //       >
      //         <option value="DNI">DNI</option>
      //         <option value="CEX">Carnet de Extranjería</option>
      //       </select>
      //     </div>
      //     <div className="form-group col-lg-6 col-md-6 col-sm-12">
      //       <label for="docNumber">Número de documento</label>
      //       <input
      //         className="form-control"
      //         type="text"
      //         id="docNumber"
      //         data-checkout="docNumber"
      //         value={this.state.docNumber}
      //         onChange={e => {
      //           this.setState({ docNumber: e.target.value });
      //         }}
      //       />
      //     </div>
      //     <div className="form-group col-lg-12 col-md-12 col-sm-12">
      //       <div className="form-group">
      //         <label htmlFor="installments">Cuotas:</label>
      //         <select
      //           id="installments"
      //           className="form-control"
      //           name="installments"
      //         >
      //           <option value="0">0 cuotas</option>
      //           <option value="1">1 cuota</option>
      //         </select>
      //       </div>
      //     </div>
      //     <div className="form-group col-lg-12 col-md-12 col-sm-12">
      //       <input
      //         type="hidden"
      //         name="amount"
      //         id="amount"
      //         value={this.props.cupon === "STARKCLASS50" ? 299 : 349}
      //       />
      //       <input
      //         type="hidden"
      //         name="description"
      //         value="Starkclass ciclo PRE uLima"
      //       />
      //       <input
      //         type="hidden"
      //         name="userId"
      //         value={this.props.auth.user.id}
      //       />
      //       <input
      //         type="hidden"
      //         name="userEmail"
      //         value={this.props.auth.user.email || ""}
      //       />

      //       <input
      //         type="submit"
      //         value={
      //           this.props.cupon === "STARKCLASS51"
      //             ? "Pagar S/ 2.00"
      //             : "Pagar S/ 349.00"
      //         }
      //         className="btn btn-lg btn-primary w-100"
      //       />
      //     </div>
      //   </div>
      // </form>
      // // </ReactShadowScroll>
    );
  }
}

const mapStateToProps = state => ({
  auth: state.auth
});

const mapDispatchToProps = (dispatch, props) => ({});

export default connect(mapStateToProps, mapDispatchToProps)(MercadoPago);
