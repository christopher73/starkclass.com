import React, { Component } from "react";
import Footer from '../Footer/footer';

export default class BadResponsePage extends Component {
    render() {
        return ( 
            <div className="container">
                <div className="row text-center h1 " style={{ paddingBottom: 10,paddingTop:100 }}>
                    <div className="col-md-3 col-sm-12 col-12  my-3">
                        <h1 style = {{ color: "#FF0000" }} > ¡OOPS!</h1>
                    </div>
                </div>
            <div className="row text-center  h3 " style={{ paddingBottom: 100 }}>
            <div className="col-md-1 col-sm-12 col-12  my-3">
                    </div>
            <div className="col-md-5 col-sm-12 col-12  my-3">
                <h1 className="h1sub h2" style={{ marginTop: 20, marginBottom: 50, color: "#707070", textAlign:"center"  }}>
                    Hubo un problema en el pago<br/>
                    verifica los datos e inténtalo de nuevo. <br/>
                </h1>
              </div>
              <div className="col-md-5 col-sm-12 col-12  my-3">
                <p className="m-0">
                  <img
                    src={"/assets/img/cara-triste-en-cuadrado-redondeado.png"}
                    alt="registrate"
                    width="250"
                  />
                </p>
              </div>
            </div>
            
            <div className="col-md-12 m-auto  text-center p-2" align="center">
                <br />
                    <img
                        src="/assets/icons/footer.png"
                        className="img-fluid"
                         alt="cello"
                     />
            </div>
            <Footer sectionR={false} />


          </div>
        );
    }
}